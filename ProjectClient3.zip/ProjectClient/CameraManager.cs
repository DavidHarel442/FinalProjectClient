﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging;
using AForge.Imaging.Filters;
using AForge.Video;
using AForge.Video.DirectShow;

namespace ProjectClient
{
    public class CameraManager
    {
        private PictureBox cameraDisplay;
        private DrawingManager drawingManager;
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;
        private bool isCapturing = false;
        private bool isTrackingFingers = false;

        // Finger tracking variables
        private Point lastFingerPosition = Point.Empty;

        // Color detection settings (optimized for red marker)
        private Color targetColor = Color.FromArgb(255, 40, 40); // Adjusted red color that's more common in markers
        private int colorThreshold = 120; // Increased threshold for better red detection
        private int minBlobSize = 15; // Reduced to detect smaller marker tips

        // Last detected tool mode
        private int lastToolMode = 1; // Default to pencil
        private DateTime lastToolChange = DateTime.MinValue;
        private const int TOOL_CHANGE_COOLDOWN_MS = 1000;
        private Point lastDrawnPosition = Point.Empty;

        // Fill operation tracking
        private DateTime lastFillAttempt = DateTime.MinValue;
        private Point lastFillPoint = Point.Empty;
        private const int FILL_COOLDOWN_MS = 1000;

        public CameraManager(PictureBox cameraDisplay, DrawingManager drawingManager)
        {
            this.cameraDisplay = cameraDisplay;
            this.drawingManager = drawingManager;
        }
        private double minXMapping = 0.2; // Minimum X value in normalized coordinates
        private double maxXMapping = 0.8; // Maximum X value in normalized coordinates
        private double minYMapping = 0.2; // Minimum Y value in normalized coordinates
        private double maxYMapping = 0.8; // Maximum Y value in normalized coordinates
        private bool mirrorXAxis = true;  // Whether to mirror the X axis

        /// <summary>
        /// Start the camera and initialize capture
        /// </summary>
        /// <returns>True if camera started successfully</returns>
        public bool StartCamera()
        {
            try
            {
                // Get list of video devices
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                {
                    MessageBox.Show("No video devices found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }

                // Create video source
                videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);
                videoSource.NewFrame += VideoSource_NewFrame;

                // Start video source
                videoSource.Start();
                isCapturing = true;

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error starting camera: {ex.Message}", "Camera Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        /// <summary>
        /// Stop the camera and release resources
        /// </summary>
        public void StopCamera()
        {
            isCapturing = false;
            isTrackingFingers = false;

            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.WaitForStop();
                videoSource.NewFrame -= VideoSource_NewFrame;
                videoSource = null;
            }
        }

        // Improved StartFrameCapture method
        public void StartFrameCapture()
        {
            if (!isCapturing)
            {
                Console.WriteLine("Cannot start drawing - camera not started");
                return;
            }

            Console.WriteLine("Starting marker tracking for drawing");
            isTrackingFingers = true;
            lastFingerPosition = Point.Empty;

            // Set tool mode to pencil if none selected
            if (drawingManager.currentToolMode == 0)
            {
                drawingManager.SetDrawingMode(1); // Default to pencil
            }

            // Make sure the drawing manager is ready
            if (drawingManager.drawingBitmap == null)
            {
                Console.WriteLine("Drawing bitmap not initialized - reinitializing");
                // You might need to add a public method to DrawingManager to reinitialize if needed
            }
        }

        // Improved StopFrameCapture method
        public void StopFrameCapture()
        {
            Console.WriteLine("Stopping marker tracking for drawing");
            isTrackingFingers = false;

            // Don't reset finger position when stopping - this allows resuming drawing 
            // from where it left off if tracking is restarted
            // lastFingerPosition = Point.Empty;
        }

        /// <summary>
        /// Event handler for processing camera frames
        /// </summary>
        private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            try
            {
                // Clone the current frame
                Bitmap frame = (Bitmap)eventArgs.Frame.Clone();

                if (isTrackingFingers)
                {
                    // Process frame for marker tracking in a way that won't affect UI responsiveness
                    ProcessFrameForFingerTracking(frame);
                }
                else
                {
                    // If not tracking, just update the display
                    UpdateCameraDisplay(frame);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in VideoSource_NewFrame: {ex.Message}");
            }
        }
        public void WidenMappingRange()
        {
            // Widen the mapping range to use more of the canvas
            minXMapping = Math.Max(0.0, minXMapping - 0.05);
            maxXMapping = Math.Min(1.0, maxXMapping + 0.05);
            minYMapping = Math.Max(0.0, minYMapping - 0.05);
            maxYMapping = Math.Min(1.0, maxYMapping + 0.05);

            Console.WriteLine($"Widened mapping range to: X({minXMapping:F2}-{maxXMapping:F2}) Y({minYMapping:F2}-{maxYMapping:F2})");
        }

        public void NarrowMappingRange()
        {
            // Narrow the mapping range to make drawing more centered
            minXMapping = Math.Min(maxXMapping - 0.1, minXMapping + 0.05);
            maxXMapping = Math.Max(minXMapping + 0.1, maxXMapping - 0.05);
            minYMapping = Math.Min(maxYMapping - 0.1, minYMapping + 0.05);
            maxYMapping = Math.Max(minYMapping + 0.1, maxYMapping - 0.05);

            Console.WriteLine($"Narrowed mapping range to: X({minXMapping:F2}-{maxXMapping:F2}) Y({minYMapping:F2}-{maxYMapping:F2})");
        }
        private void ProcessFrameForFingerTracking(Bitmap frame)
        {
            try
            {
                // Create a modified version of the frame to make color detection easier
                Bitmap enhancedFrame = (Bitmap)frame.Clone();

                // Enhance contrast and saturation for better color detection
                ContrastCorrection contrastFilter = new ContrastCorrection((int)(float)1.5);
                contrastFilter.ApplyInPlace(enhancedFrame);

                SaturationCorrection saturationFilter = new SaturationCorrection((float)1.5);
                saturationFilter.ApplyInPlace(enhancedFrame);

                // Create a color filter to isolate the marker
                EuclideanColorFiltering filter = new EuclideanColorFiltering
                {
                    CenterColor = new RGB(targetColor.R, targetColor.G, targetColor.B),
                    Radius = (short)colorThreshold,
                    FillOutside = false
                };

                // Keep a copy of the frame for debugging
                Bitmap debugFrame = (Bitmap)frame.Clone();
                Bitmap filteredImage = (Bitmap)enhancedFrame.Clone();

                // Apply the filter to isolate the color
                filter.ApplyInPlace(filteredImage);

                // Find blobs in the filtered image
                BlobCounter blobCounter = new BlobCounter
                {
                    FilterBlobs = true,
                    MinHeight = minBlobSize,
                    MinWidth = minBlobSize,
                    ObjectsOrder = ObjectsOrder.Size // Sort by size (largest first)
                };

                blobCounter.ProcessImage(filteredImage);
                Blob[] blobs = blobCounter.GetObjectsInformation();

                // Add debugging overlay to the frame
                using (Graphics g = Graphics.FromImage(debugFrame))
                {
                    using (Font font = new Font("Arial", 10))
                    using (SolidBrush brush = new SolidBrush(Color.Yellow))
                    {
                        g.DrawString($"Target: R={targetColor.R},G={targetColor.G},B={targetColor.B}", font, brush, 10, 10);
                        g.DrawString($"Blobs: {blobs.Length}", font, brush, 10, 30);
                    }

                    // Draw rectangles around all detected blobs
                    using (Pen blobPen = new Pen(Color.Magenta, 2))
                    {
                        foreach (Blob blob in blobs)
                        {
                            g.DrawRectangle(blobPen, blob.Rectangle);

                            // Label blob sizes
                            using (Font font = new Font("Arial", 8))
                            using (SolidBrush brush = new SolidBrush(Color.White))
                            {
                                g.DrawString($"{blob.Area}", font, brush,
                                    blob.Rectangle.X, blob.Rectangle.Y - 10);
                            }
                        }
                    }

                    // Add thumbnail of filtered image in corner
                    int thumbnailSize = 150;
                    g.DrawImage(filteredImage, frame.Width - thumbnailSize, 0, thumbnailSize, thumbnailSize * frame.Height / frame.Width);
                }

                // Process the detected blobs
                if (blobs.Length > 0)
                {
                    // Use the largest blob
                    Blob largestBlob = blobs[0]; // Already sorted by size

                    // Only consider blobs of sufficient size
                    if (largestBlob.Area > 50) // Minimum area to consider as a marker
                    {
                        // Get the center point of the blob
                        Point markerPosition = new Point(
                            (int)largestBlob.CenterOfGravity.X,
                            (int)largestBlob.CenterOfGravity.Y
                        );

                        // Add visual debugging
                        using (Graphics g = Graphics.FromImage(debugFrame))
                        {
                            // Draw crosshair at detected position
                            using (Pen crosshairPen = new Pen(Color.Yellow, 2))
                            {
                                g.DrawLine(crosshairPen,
                                    markerPosition.X - 15, markerPosition.Y,
                                    markerPosition.X + 15, markerPosition.Y);
                                g.DrawLine(crosshairPen,
                                    markerPosition.X, markerPosition.Y - 15,
                                    markerPosition.X, markerPosition.Y + 15);
                            }

                            // Show coordinates
                            using (Font font = new Font("Arial", 10))
                            using (SolidBrush brush = new SolidBrush(Color.Yellow))
                            {
                                g.DrawString($"Marker: {markerPosition.X},{markerPosition.Y}", font, brush, 10, 70);
                                g.DrawString($"Area: {largestBlob.Area}", font, brush, 10, 90);
                            }
                        }

                        // Handle drawing with the detected marker
                        HandleMarkerDrawing(markerPosition, frame.Width, frame.Height);
                    }
                    else
                    {
                        // Reset drawing if blob is too small
                        lastFingerPosition = Point.Empty;
                    }
                }
                else
                {
                    // No blobs detected
                    using (Graphics g = Graphics.FromImage(debugFrame))
                    {
                        using (Font font = new Font("Arial", 14))
                        using (SolidBrush brush = new SolidBrush(Color.Red))
                        {
                            g.DrawString("NO MARKER DETECTED", font, brush,
                                frame.Width / 2 - 100, frame.Height / 2);
                        }
                    }

                    // Reset drawing coordinates when marker is lost
                    lastFingerPosition = Point.Empty;
                }

                // Update the camera display with debugging visuals
                UpdateCameraDisplay(debugFrame);

                // Clean up bitmaps
                enhancedFrame.Dispose();
                filteredImage.Dispose();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing frame: {ex.Message}");
            }
        }
        private void HandleMarkerDrawing(Point markerPosition, int frameWidth, int frameHeight)
        {
            try
            {
                // Map camera coordinates to drawing canvas coordinates
                Point canvasPoint = MapCameraToCanvas(markerPosition, frameWidth, frameHeight);

                // First detection, just store the position
                if (lastFingerPosition == Point.Empty)
                {
                    lastFingerPosition = markerPosition;
                    Console.WriteLine($"First marker detection at {markerPosition}, canvas point {canvasPoint}");

                    // Don't return here if we're in the middle of drawing
                    // This allows continuous drawing even if tracking was temporarily lost
                    if (!isTrackingFingers)
                    {
                        return;
                    }
                }

                // Calculate movement since last position
                int deltaX = markerPosition.X - lastFingerPosition.X;
                int deltaY = markerPosition.Y - lastFingerPosition.Y;
                double distance = Math.Sqrt(deltaX * deltaX + deltaY * deltaY);

                // Map previous position to canvas coordinates
                Point previousCanvasPoint = MapCameraToCanvas(lastFingerPosition, frameWidth, frameHeight);

                // Only draw if there's sufficient movement - reduced for more sensitivity
                if (distance >= 3)
                {
                    Console.WriteLine($"Marker moved {distance:F1} pixels from {lastFingerPosition} to {markerPosition}");
                    Console.WriteLine($"Canvas points: {previousCanvasPoint} to {canvasPoint}");

                    // Create drawing action based on current tool
                    DrawingAction drawAction = new DrawingAction
                    {
                        Type = drawingManager.currentToolMode == 1 ? "DrawLine" : "Erase",
                        StartPoint = previousCanvasPoint,
                        EndPoint = canvasPoint,
                        Color = drawingManager.currentToolMode == 1 ? drawingManager.drawingPen.Color : Color.White,
                        Size = drawingManager.currentToolMode == 1 ? drawingManager.drawingPen.Width : drawingManager.eraser.Width
                    };

                    // Send drawing asynchronously so it doesn't interrupt tracking
                    Task.Run(() => {
                        try
                        {
                            // Get the parent form to access the TCP server
                            Form parentForm = drawingManager.drawingCanvas.FindForm();
                            if (parentForm is SharedDrawingForm form && form.tcpServer != null)
                            {
                                // Apply drawing on UI thread
                                parentForm.Invoke(new Action(() => {
                                    // First apply drawing locally
                                    drawingManager.ApplyDrawingAction(drawAction);

                                    // Then send to server for other clients
                                    form.tcpServer.SendMessage("DrawingAction", drawAction.Serialize());
                                    Console.WriteLine($"Drawing action sent: {drawAction.Type} from {drawAction.StartPoint} to {drawAction.EndPoint}");
                                }));
                            }
                            else
                            {
                                Console.WriteLine("Could not access SharedDrawingForm or tcpServer");
                            }
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"Error sending drawing action: {ex.Message}");
                        }
                    });

                    // Update last marker position
                    lastFingerPosition = markerPosition;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in HandleMarkerDrawing: {ex.Message}");
            }
        }


        private Point MapCameraToCanvas(Point cameraPoint, int frameWidth, int frameHeight)
        {
            try
            {
                // Get drawing canvas dimensions
                int canvasWidth = drawingManager.drawingCanvas.Width;
                int canvasHeight = drawingManager.drawingCanvas.Height;

                // Log input parameters for debugging
                Console.WriteLine($"MapCameraToCanvas: Camera({cameraPoint.X},{cameraPoint.Y}) Frame({frameWidth}x{frameHeight}) Canvas({canvasWidth}x{canvasHeight})");

                // Simple direct proportion mapping (no mirroring, no scaling factors)
                int canvasX = (int)((double)cameraPoint.X / frameWidth * canvasWidth);
                int canvasY = (int)((double)cameraPoint.Y / frameHeight * canvasHeight);

                // Ensure coordinates are within bounds
                canvasX = Math.Max(0, Math.Min(canvasX, canvasWidth - 1));
                canvasY = Math.Max(0, Math.Min(canvasY, canvasHeight - 1));

                Console.WriteLine($"Mapping result: Camera({cameraPoint.X},{cameraPoint.Y}) → Canvas({canvasX},{canvasY})");

                return new Point(canvasX, canvasY);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in MapCameraToCanvas: {ex.Message}");
                // Return a default point in case of error
                return new Point(0, 0);
            }
        }












        /// <summary>
        /// Update the camera display with the current frame
        /// </summary>
        private void UpdateCameraDisplay(Bitmap frame)
        {
            try
            {
                // Need to safely update UI from potentially different thread
                if (cameraDisplay.InvokeRequired)
                {
                    cameraDisplay.Invoke(new Action(() =>
                    {
                        System.Drawing.Image oldImage = cameraDisplay.Image;
                        cameraDisplay.Image = frame;
                        oldImage?.Dispose();
                    }));
                }
                else
                {
                    System.Drawing.Image oldImage = cameraDisplay.Image;
                    cameraDisplay.Image = frame;
                    oldImage?.Dispose();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error updating camera display: {ex.Message}");
            }
        }

        /// <summary>
        /// Set the target color to track
        /// </summary>
        public void SetTargetColor(Color color)
        {
            targetColor = color;
            Console.WriteLine($"Target color set to R={color.R}, G={color.G}, B={color.B}");

            // Adjust the blob detection parameters based on the color
            // Red markers need different parameters than blue or green
            if (color.R > Math.Max(color.G, color.B) + 50)
            {
                // It's a red marker
                colorThreshold = 100;
                minBlobSize = 15;
                Console.WriteLine("Red marker detected - adjusting parameters");
            }
            else if (color.G > Math.Max(color.R, color.B) + 50)
            {
                // It's a green marker
                colorThreshold = 90;
                minBlobSize = 15;
                Console.WriteLine("Green marker detected - adjusting parameters");
            }
            else if (color.B > Math.Max(color.R, color.G) + 50)
            {
                // It's a blue marker
                colorThreshold = 80;
                minBlobSize = 15;
                Console.WriteLine("Blue marker detected - adjusting parameters");
            }
            else
            {
                // It's some other color
                colorThreshold = 120;
                minBlobSize = 15;
                Console.WriteLine("Other color marker detected - using default parameters");
            }
        }

        public void CalibrateColorTracking(Point samplePoint)
        {
            if (cameraDisplay.Image != null)
            {
                try
                {
                    // Create a bitmap from the current camera image
                    Bitmap currentFrame = new Bitmap(cameraDisplay.Image);

                    // Make sure the sample point is within the frame bounds
                    int x = Math.Min(Math.Max(samplePoint.X, 0), currentFrame.Width - 1);
                    int y = Math.Min(Math.Max(samplePoint.Y, 0), currentFrame.Height - 1);

                    // Sample the color at the clicked point
                    Color sampledColor = currentFrame.GetPixel(x, y);

                    // Set as the target color
                    targetColor = sampledColor;

                    // Adjust the threshold based on color brightness
                    // (adjust for more accurate detection based on marker color)
                    int brightness = (sampledColor.R + sampledColor.G + sampledColor.B) / 3;
                    colorThreshold = brightness < 128 ? 80 : 120; // Lower threshold for darker colors

                    Console.WriteLine($"Calibrated to color: R={sampledColor.R}, G={sampledColor.G}, B={sampledColor.B}");
                    Console.WriteLine($"Threshold set to: {colorThreshold}");

                    // Cleanup
                    currentFrame.Dispose();

                    // Reset tracking state
                    lastFingerPosition = Point.Empty;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error calibrating color: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine("No camera image available for calibration");
            }
        }
    }
}