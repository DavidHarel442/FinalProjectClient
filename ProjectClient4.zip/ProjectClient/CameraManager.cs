﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using AForge.Video;
using AForge.Video.DirectShow;
using Emgu.Util;

namespace ProjectClient
{
    public class CameraManager
    {
        private PictureBox cameraPictureBox;     // Where we display the camera feed
        private DrawingManager drawingManager;   // Reference to your drawing manager (if needed later)

        private FilterInfoCollection videoDevices;  // List of camera devices
        private VideoCaptureDevice videoSource;      // The selected camera device

        private bool isCalibrated = false;
        private Color targetColor;              // Color we want to track
        private const int colorThreshold = 10;  // How close a pixel's color has to be to our target color

        private int cameraWidth;
        private int cameraHeight;
        private int boxWidth;
        private int boxHeight;

        private SharedDrawingForm parentForm;

        // Camera quality settings
        private int captureWidth = 640;   // Moderate resolution width
        private int captureHeight = 480;  // Moderate resolution height
        private bool skipFrames = false;  // Option to process every other frame
        private int frameCounter = 0;
        private int samplingStep = 2;     // Pixel sampling density (lower = more accurate but slower)

        // Advanced motion smoothing settings
        private bool useSmoothing = true;      // Apply smoothing to marker position
        private Queue<Point> recentPositions = new Queue<Point>(10); // For position smoothing
        private double smoothingStrength = 0.7; // How much to smooth (0.0-1.0)
        private Point? lastReportedPosition = null; // Last position sent to drawing system
        private int minDistanceThreshold = 2;   // Minimum pixel change to report a new position


        // Constructor
        public CameraManager(PictureBox cameraPictureBox, DrawingManager drawingManager, SharedDrawingForm parentForm)
        {
            this.cameraPictureBox = cameraPictureBox;
            this.drawingManager = drawingManager;
            boxHeight = cameraPictureBox.Height;
            boxWidth = cameraPictureBox.Width;
            this.parentForm = parentForm;
        }

        /// <summary>
        /// Call this to enumerate and start the camera
        /// </summary>
        public bool StartCamera()
        {
            try
            {
                // 1) Find all video input devices
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (videoDevices.Count == 0)
                {
                    MessageBox.Show("No camera device found!");
                    return false;
                }

                // 2) Select the first camera or allow user to pick
                videoSource = new VideoCaptureDevice(videoDevices[0].MonikerString);

                // Set lower resolution video capabilities
                SetLowResolutionCapabilities();

                // 3) Hook the NewFrame event to process each frame
                videoSource.NewFrame += VideoSource_NewFrame;

                // 4) Start the camera
                videoSource.Start();

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error starting camera: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Sets the camera to use a lower resolution to improve performance
        /// </summary>
        private void SetLowResolutionCapabilities()
        {
            try
            {
                // Get available video capabilities
                var videoCapabilities = videoSource.VideoCapabilities;
                if (videoCapabilities != null && videoCapabilities.Length > 0)
                {
                    // Try to find a video mode close to our target resolution
                    var selectedMode = videoCapabilities
                        .OrderBy(caps => Math.Abs(caps.FrameSize.Width - captureWidth) +
                                 Math.Abs(caps.FrameSize.Height - captureHeight))
                        .FirstOrDefault();

                    if (selectedMode != null)
                    {
                        Console.WriteLine($"Selected camera mode: {selectedMode.FrameSize.Width}x{selectedMode.FrameSize.Height} at {selectedMode.AverageFrameRate} FPS");
                        videoSource.VideoResolution = selectedMode;
                    }
                    else
                    {
                        Console.WriteLine("No suitable video mode found. Using default.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error setting video capabilities: {ex.Message}");
                // Continue with default settings
            }
        }

        /// <summary>
        /// Configure camera quality settings
        /// </summary>
        /// <param name="width">Desired capture width</param>
        /// <param name="height">Desired capture height</param>
        /// <param name="skipFrames">Whether to process every other frame</param>
        /// <param name="samplingStep">Pixel sampling density (1=every pixel, 2=every other, etc.)</param>
        /// <param name="smoothing">Whether to apply position smoothing</param>
        /// <param name="smoothStrength">Smoothing strength between 0.0 and 1.0 (higher = smoother)</param>
        /// <param name="minMoveThreshold">Minimum pixels moved before updating position (anti-jitter)</param>
        public void SetQualitySettings(int width, int height, bool skipFrames,
                                      int samplingStep = 2, bool smoothing = true,
                                      double smoothStrength = 0.7, int minMoveThreshold = 2)
        {
            this.captureWidth = width;
            this.captureHeight = height;
            this.skipFrames = skipFrames;
            this.samplingStep = samplingStep;
            this.useSmoothing = smoothing;
            this.smoothingStrength = Math.Max(0, Math.Min(1.0, smoothStrength)); // Clamp between 0-1
            this.minDistanceThreshold = Math.Max(0, minMoveThreshold);

            // Clear position history when changing settings
            recentPositions.Clear();
            lastReportedPosition = null;

            // Apply if camera is already running
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.WaitForStop();

                // Restart with new settings
                SetLowResolutionCapabilities();
                videoSource.Start();
            }
        }

        /// <summary>
        /// Applies advanced smoothing to marker positions using a combination of techniques
        /// </summary>
        private Point SmoothPosition(Point newPosition)
        {
            // 1. Add the new position to our history
            recentPositions.Enqueue(newPosition);

            // Keep only the most recent positions (queue size limit)
            while (recentPositions.Count > 10)
            {
                recentPositions.Dequeue();
            }

            // Skip smoothing if we don't have enough history
            if (recentPositions.Count < 3)
            {
                return newPosition;
            }

            // 2. Calculate weighted moving average (more recent positions have more weight)
            double sumX = 0, sumY = 0;
            double totalWeight = 0;
            double weight = 1.0;

            foreach (var pos in recentPositions.Reverse()) // Most recent first
            {
                sumX += pos.X * weight;
                sumY += pos.Y * weight;
                totalWeight += weight;
                weight *= 0.8; // Exponential decay of weights for older positions
            }

            Point avgPosition = new Point(
                (int)(sumX / totalWeight),
                (int)(sumY / totalWeight)
            );

            // 3. Apply exponential smoothing between this average and the last reported position
            Point smoothedPosition;
            if (lastReportedPosition.HasValue)
            {
                // Blend between previous position and new position based on smoothing strength
                // Higher smoothingStrength = more influence from previous position
                smoothedPosition = new Point(
                    (int)(lastReportedPosition.Value.X * smoothingStrength + avgPosition.X * (1 - smoothingStrength)),
                    (int)(lastReportedPosition.Value.Y * smoothingStrength + avgPosition.Y * (1 - smoothingStrength))
                );

                // 4. Position thresholding - only update if moved more than threshold
                if (Distance(smoothedPosition, lastReportedPosition.Value) <= minDistanceThreshold)
                {
                    return lastReportedPosition.Value; // No significant movement, keep previous position
                }
            }
            else
            {
                smoothedPosition = avgPosition;
            }

            // Update last reported position for next frame
            lastReportedPosition = smoothedPosition;

            return smoothedPosition;
        }

        /// <summary>
        /// Calculates Euclidean distance between two points
        /// </summary>
        private double Distance(Point p1, Point p2)
        {
            int dx = p1.X - p2.X;
            int dy = p1.Y - p2.Y;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        private Bitmap ResizeImage(Bitmap original, int newWidth, int newHeight)
        {
            Bitmap resized = new Bitmap(newWidth, newHeight);
            using (Graphics g = Graphics.FromImage(resized))
            {
                // Use bilinear for better quality while still being fast
                g.CompositingQuality = System.Drawing.Drawing2D.CompositingQuality.HighSpeed;
                g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.Bilinear;
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.None;
                g.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.Half;
                g.DrawImage(original, 0, 0, newWidth, newHeight);
            }
            return resized;
        }

        /// <summary>
        /// Event that fires for each new frame from the camera
        /// </summary>
        private void VideoSource_NewFrame(object sender, NewFrameEventArgs eventArgs)
        {
            // Skip frames if enabled
            if (skipFrames)
            {
                frameCounter++;
                if (frameCounter % 2 != 0)
                {
                    return; // Skip this frame
                }
            }

            Bitmap originalFrame = null;
            Bitmap flippedFrame = null;

            try
            {
                // Create a clone of the frame to work with
                originalFrame = (Bitmap)eventArgs.Frame.Clone();

                // Store the camera dimensions
                cameraWidth = originalFrame.Width;
                cameraHeight = originalFrame.Height;

                // Flip the frame horizontally for a more intuitive view
                flippedFrame = FlipImageHorizontally(originalFrame);

                // Create a scaled version for display
                Bitmap scaledFrame = ResizeImage(flippedFrame, boxWidth, boxHeight);

                // If calibrated, find the marker in the flipped frame
                Point? markerCenter = null;
                if (isCalibrated)
                {
                    markerCenter = FindMarker(flippedFrame, targetColor);

                    if (markerCenter.HasValue)
                    {
                        // Draw marker indicator on the scaled frame
                        using (Graphics g = Graphics.FromImage(scaledFrame))
                        {
                            // Adjust coordinates for scaled frame
                            float scaleX = (float)boxWidth / cameraWidth;
                            float scaleY = (float)boxHeight / cameraHeight;

                            int scaledX = (int)(markerCenter.Value.X * scaleX);
                            int scaledY = (int)(markerCenter.Value.Y * scaleY);

                            // Draw a visible indicator
                            g.FillEllipse(Brushes.Red, scaledX - 3, scaledY - 3, 6, 6);
                        }

                        // Forward the marker position to the parent form for drawing
                        if (parentForm != null)
                        {
                            parentForm.BeginInvoke(new Action(() => {
                                parentForm.ProcessMarkerPosition(
                                    markerCenter.Value,
                                    new Size(cameraWidth, cameraHeight)
                                );
                            }));
                        }
                    }
                }

                // Debug logging - reduced frequency
                if (DateTime.Now.Second % 10 == 0 && DateTime.Now.Millisecond < 50)
                {
                    Color pixelColor = flippedFrame.GetPixel(flippedFrame.Width / 2, flippedFrame.Height / 2);
                    Console.WriteLine($"Center pixel = R:{pixelColor.R} G:{pixelColor.G} B:{pixelColor.B}");

                    if (isCalibrated)
                    {
                        Console.WriteLine($"Distance to target color = {ColorDistance(pixelColor, targetColor)}");
                    }
                }

                // Create a closure to capture the local scaledFrame for the delegate
                Bitmap frameToShow = scaledFrame;

                Action updateUI = () => {
                    try
                    {
                        // Dispose of previous image before assigning new one
                        var oldImage = cameraPictureBox.Image;
                        cameraPictureBox.Image = frameToShow;

                        if (oldImage != null && oldImage != frameToShow)
                        {
                            oldImage.Dispose();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"UI update error: {ex.Message}");
                    }
                };

                // Invoke on UI thread if needed
                if (cameraPictureBox.InvokeRequired)
                {
                    try
                    {
                        cameraPictureBox.BeginInvoke(updateUI);
                    }
                    catch (ObjectDisposedException)
                    {
                        // Form may be closing, just exit gracefully
                        frameToShow.Dispose();
                    }
                }
                else
                {
                    updateUI();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Frame processing error: {ex.Message}");

                if (ex is ObjectDisposedException)
                {
                    Console.WriteLine("Object disposed exception - the form may be closing.");
                }
            }
            finally
            {
                // Ensure frames are always disposed if we created them
                if (originalFrame != null)
                {
                    originalFrame.Dispose();
                }

                if (flippedFrame != null)
                {
                    flippedFrame.Dispose();
                }
            }
        }

        /// <summary>
        /// Find the marker in the frame by scanning for the closest color to "targetColor"
        /// using an adaptive sampling approach with smoothing
        /// </summary>
        private Point? FindMarker(Bitmap frame, Color targetColor)
        {
            // Use the configurable sampling step
            int width = frame.Width;
            int height = frame.Height;

            BitmapData bitmapData = frame.LockBits(
                new Rectangle(0, 0, width, height),
                ImageLockMode.ReadOnly,
                PixelFormat.Format24bppRgb);

            int stride = bitmapData.Stride;
            IntPtr scan0 = bitmapData.Scan0;

            // Store sum of x, y, and total count of pixels in range
            long sumX = 0, sumY = 0;
            long inRangeCount = 0;

            // Store weighted values for better accuracy
            long weightedSumX = 0, weightedSumY = 0;
            long totalWeight = 0;

            unsafe
            {
                for (int y = 0; y < height; y += samplingStep)
                {
                    byte* row = (byte*)scan0 + (y * stride);
                    for (int x = 0; x < width; x += samplingStep)
                    {
                        // BGR format
                        byte b = row[x * 3 + 0];
                        byte g = row[x * 3 + 1];
                        byte r = row[x * 3 + 2];

                        Color currentColor = Color.FromArgb(r, g, b);

                        // Compare color distance
                        int distance = ColorDistance(currentColor, targetColor);
                        if (distance < colorThreshold)
                        {
                            // Calculate a weight based on how close the color match is
                            // Closer matches get higher weights
                            int weight = colorThreshold - distance;

                            // Regular averaging
                            sumX += x;
                            sumY += y;
                            inRangeCount++;

                            // Weighted averaging for better precision
                            weightedSumX += x * weight;
                            weightedSumY += y * weight;
                            totalWeight += weight;
                        }
                    }
                }
            }

            frame.UnlockBits(bitmapData);

            if (inRangeCount > 0)
            {
                Point rawPosition;

                // Use weighted average if we have weights, otherwise use regular average
                if (totalWeight > 0)
                {
                    int centerX = (int)(weightedSumX / totalWeight);
                    int centerY = (int)(weightedSumY / totalWeight);
                    rawPosition = new Point(centerX, centerY);
                }
                else
                {
                    int centerX = (int)(sumX / inRangeCount);
                    int centerY = (int)(sumY / inRangeCount);
                    rawPosition = new Point(centerX, centerY);
                }

                // Apply position smoothing if enabled
                Point finalPosition = useSmoothing && recentPositions.Count > 0
                    ? SmoothPosition(rawPosition)
                    : rawPosition;

                // Very minimal logging
                if (inRangeCount > 20 && DateTime.Now.Second % 10 == 0 && DateTime.Now.Millisecond < 50)
                {
                    Console.WriteLine($"Found {inRangeCount} matching pixels");
                }

                return finalPosition;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Simple distance metric between two colors (Euclidean in RGB space).
        /// </summary>
        private int ColorDistance(Color c1, Color c2)
        {
            int rDiff = c1.R - c2.R;
            int gDiff = c1.G - c2.G;
            int bDiff = c1.B - c2.B;
            return (int)Math.Sqrt(rDiff * rDiff + gDiff * gDiff + bDiff * bDiff);
        }

        /// <summary>
        /// Stop camera
        /// </summary>
        public void StopCamera()
        {
            if (videoSource != null && videoSource.IsRunning)
            {
                videoSource.SignalToStop();
                videoSource.NewFrame -= VideoSource_NewFrame;
                videoSource = null;
            }
        }

        /// <summary>
        /// Grab the color from the user's click on the camera feed.
        /// This "calibrates" the marker color to track.
        /// </summary>
        /// <param name="clickLocation">Coordinates where the user clicked in the PictureBox</param>
        public void CalibrateColorTracking(Point clickLocation)
        {
            Console.WriteLine($"Clicked {clickLocation.X},{clickLocation.Y} in the PictureBox");
            if (cameraPictureBox.Image == null)
                throw new Exception("No camera image to calibrate from!");

            Bitmap bmp = (Bitmap)cameraPictureBox.Image;
            if (clickLocation.X < 0 || clickLocation.X >= bmp.Width ||
                clickLocation.Y < 0 || clickLocation.Y >= bmp.Height)
            {
                throw new Exception("Click location is outside the image bounds.");
            }

            // Grab the pixel color
            Color clickedColor = bmp.GetPixel(clickLocation.X, clickLocation.Y);
            targetColor = clickedColor;
            isCalibrated = true;

            // Optionally console log:
            Console.WriteLine($"Calibrated color: R={clickedColor.R}, G={clickedColor.G}, B={clickedColor.B}");
        }

        private Bitmap FlipImageHorizontally(Bitmap source)
        {
            // Create a new bitmap with the same dimensions
            Bitmap flipped = new Bitmap(source.Width, source.Height);

            // Create graphics object to do the flipping
            using (Graphics g = Graphics.FromImage(flipped))
            {
                // Set up transformation to flip horizontally
                g.TranslateTransform(source.Width, 0);
                g.ScaleTransform(-1, 1);

                // Draw the original image with the transformation applied
                g.DrawImage(source, 0, 0, source.Width, source.Height);
            }

            return flipped;
        }

        private void ColorToHSL(Color color, out float h, out float s, out float l)
        {
            // Normalized R, G, B in [0..1]
            float r = color.R / 255f;
            float g = color.G / 255f;
            float b = color.B / 255f;

            float max = Math.Max(r, Math.Max(g, b));
            float min = Math.Min(r, Math.Min(g, b));
            float diff = max - min;

            l = (max + min) / 2f;

            if (Math.Abs(diff) < 0.00001f)
            {
                // Grayish color
                h = 0;
                s = 0;
                return;
            }

            // Saturation
            if (l < 0.5f) s = diff / (max + min);
            else s = diff / (2f - max - min);

            // Hue
            float rd = (((max - r) / 6f) + (diff / 2f)) / diff;
            float gd = (((max - g) / 6f) + (diff / 2f)) / diff;
            float bd = (((max - b) / 6f) + (diff / 2f)) / diff;

            if (r == max) h = bd - gd;
            else if (g == max) h = (1f / 3f) + rd - bd;
            else h = (2f / 3f) + gd - rd;

            if (h < 0) h += 1;
            if (h > 1) h -= 1;
        }

    }
}